# Dukaan AI — Public Launch MVP

## What it does
- Product catalog stored locally
- Quick invoice
- Discount calculation
- Print/save invoice as PDF
- Share invoice summary
- WhatsApp sales message
- Optional customer WhatsApp number
- Installable PWA manifest

## Publish
Upload `index.html` and `manifest.json` to any static web host (for example GitHub Pages, Netlify, Vercel, or Cloudflare Pages).

## Monetization
Keep the basic tool free. Premium can later include:
- Cloud sync
- Customer CRM
- Multiple shops/staff
- Branded invoices
- AI marketing copy
- Automated follow-ups
- Sales analytics

Revenue is not guaranteed; validate with real shopkeepers before spending heavily.
