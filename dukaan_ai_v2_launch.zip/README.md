Dukaan AI v2. Upload index.html and manifest.json to the root of your GitHub Pages repository.
